<?php

if (!defined('ABSPATH')) {
    exit;
}

class DISI_FluentForms {

    public function __construct() {

        add_action(
            'fluentform_submission_inserted',
            [$this, 'capture_submission'],
            10,
            3
        );
    }

    public function capture_submission(
        $entry_id,
        $form_data,
        $form
    ) {

        $config =
        DISI_Settings::get_configuration();

        $registration_type = '';

        /*
        |--------------------------------------------------------------------------
        | Determine Registration Type
        |--------------------------------------------------------------------------
        */

        if (
            intval($config['participant_form']) ===
            intval($form->id)
        ) {

            $registration_type =
            'participant';
        }

        if (
            intval($config['vendor_form']) ===
            intval($form->id)
        ) {

            $registration_type =
            'vendor';
        }

        if (
            intval($config['partner_form']) ===
            intval($form->id)
        ) {

            $registration_type =
            'partner';
        }

        if (empty($registration_type)) {
            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Find Email
        |--------------------------------------------------------------------------
        */

        $email = '';

        foreach ($form_data as $key => $value) {

            if (
                !is_array($value) &&
                filter_var(
                    $value,
                    FILTER_VALIDATE_EMAIL
                )
            ) {

                $email = $value;
                break;
            }
        }

        if (empty($email)) {
            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Extract Common Fields
        |--------------------------------------------------------------------------
        */

        $phone =
            $form_data['phone_number']
            ?? '';

        $first_name = '';

        $last_name = '';

        if (
            isset($form_data['full_name']) &&
            is_array($form_data['full_name'])
        ) {

            $first_name =
                sanitize_text_field(
                    $form_data['full_name']['first_name']
                    ?? ''
                );

            $last_name =
                sanitize_text_field(
                    $form_data['full_name']['last_name']
                    ?? ''
                );
        }

        $business_name =
            $form_data['business_name']
            ?? '';

        /*
        |--------------------------------------------------------------------------
        | Create Registration
        |--------------------------------------------------------------------------
        */

        $result =
        DISI_Registration_Manager::create([

            'registration_type' =>
                $registration_type,

            'source_plugin' =>
                'Fluent Forms',

            'form_id' =>
                $form->id,

            'email' =>
                $email,

            'phone' =>
                $phone,

            'first_name' =>
                $first_name,

            'last_name' =>
                $last_name,

            'business_name' =>
                $business_name,

            'submitted_data' =>
                $form_data

        ]);

        /*
        |--------------------------------------------------------------------------
        | Log Errors
        |--------------------------------------------------------------------------
        */

        if (
            is_wp_error($result)
        ) {

            error_log(
                'DISI REGISTRATION ERROR: ' .
                $result->get_error_message()
            );

            return;
        }
    }
}