<?php

if (!defined('ABSPATH')) {
    exit;
}

class DISI_Email {

    public static function send_approval_email(
        $registration,
        $user_id
    ) {

        error_log(
            'DISI EMAIL METHOD STARTED'
        );

        $user = get_user_by(
            'ID',
            $user_id
        );

        if (!$user) {
            return false;
        }

        $reset_key =
        get_password_reset_key(
            $user
        );

        $reset_url =
        network_site_url(
            'wp-login.php?action=rp&key=' .
            $reset_key .
            '&login=' .
            rawurlencode(
                $user->user_login
            ),
            'login'
        );

        $registration_number =
        DISI_Registration_Manager::get_registration_number(
            $registration
        );

        $type =
        ucfirst(
            $registration->registration_type
        );

        $subject =
        'Your DISI Summit Registration Has Been Approved';

        $logo =
        'https://disisummit.org/wp-content/uploads/2026/06/cropped-Black_White_Minimal_Professional_Corporate_Business_Logo-removebg-preview.png';

        $message = '

        <html>

        <body style="
            margin:0;
            padding:0;
            background:#f3f4f6;
            font-family:Arial,sans-serif;
        ">

        <div style="
            max-width:700px;
            margin:30px auto;
            background:#ffffff;
            border-radius:12px;
            overflow:hidden;
        ">

            <div style="
                background:#22c55e;
                padding:30px;
                text-align:center;
            ">

                <img
                src="' . esc_url($logo) . '"
                style="
                    max-width:180px;
                "
                >

            </div>

            <div style="
                padding:40px;
            ">

                <h2>
                    Welcome to DISI Summit
                </h2>

                <p>

                    Congratulations!

                    Your ' . esc_html($type) . '
                    registration has been approved.

                </p>

                <table
                cellpadding="8"
                style="
                    width:100%;
                    margin:20px 0;
                    border-collapse:collapse;
                "
                >

                    <tr>
                        <td>
                            Registration Number
                        </td>

                        <td>
                            <strong>' .
                            esc_html(
                                $registration_number
                            ) .
                            '</strong>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            Registration Type
                        </td>

                        <td>
                            <strong>' .
                            esc_html($type) .
                            '</strong>
                        </td>
                    </tr>

                </table>

                <p>

                    Click the button below
                    to set your password
                    and activate your account.

                </p>

                <p
                style="
                    text-align:center;
                    margin:40px 0;
                "
                >

                    <a
                    href="' . esc_url($reset_url) . '"
                    style="
                        background:#f59e0b;
                        color:#ffffff;
                        text-decoration:none;
                        padding:14px 28px;
                        border-radius:8px;
                        display:inline-block;
                        font-weight:bold;
                    "
                    >

                    Activate Account

                    </a>

                </p>

                <p>

                    Website:

                    <a href="https://disisummit.org">
                        disisummit.org
                    </a>

                </p>

            </div>

        </div>

        </body>

        </html>

        ';

        $headers = [

            'Content-Type: text/html; charset=UTF-8',

            'From: DISI Summit Portal <noreply@disisummit.org>'

        ];

        return wp_mail(
            $user->user_email,
            $subject,
            $message,
            $headers
        );
    }
}