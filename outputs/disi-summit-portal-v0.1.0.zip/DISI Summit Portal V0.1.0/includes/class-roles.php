<?php

if (!defined('ABSPATH')) {
    exit;
}

class DISI_Roles {

    public static function create_roles() {

        add_role(
            'disi_participant',
            'DISI Participant',
            [
                'read' => true
            ]
        );

        add_role(
            'disi_vendor',
            'DISI Vendor',
            [
                'read' => true
            ]
        );

        add_role(
            'disi_partner',
            'DISI Partner',
            [
                'read' => true
            ]
        );
    }
}