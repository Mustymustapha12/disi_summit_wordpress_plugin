<?php

if (!defined('ABSPATH')) {
    exit;
}

/*
|--------------------------------------------------------------------------
| Save Configuration
|--------------------------------------------------------------------------
*/

if (
    isset($_POST['disi_save_configuration']) &&
    check_admin_referer(
        'disi_save_configuration_action'
    )
) {

    $config = [

        'provider' => sanitize_text_field(
            $_POST['provider'] ?? ''
        ),

        'participant_form' => intval(
            $_POST['participant_form'] ?? 0
        ),

        'vendor_form' => intval(
            $_POST['vendor_form'] ?? 0
        ),

        'partner_form' => intval(
            $_POST['partner_form'] ?? 0
        )

    ];

    DISI_Settings::save_configuration(
        $config
    );

    echo '
    <div class="notice notice-success">
        <p>Configuration saved successfully.</p>
    </div>
    ';
}

$config = DISI_Settings::get_configuration();


$provider =
$_POST['provider']
?? $config['provider']
?? '';

$forms = [];

if (!empty($provider)) {

    $forms =
    DISI_Form_Provider::get_forms(
        $provider
    );
}

?>

<div class="wrap">

    <h1>DISI Portal Integrations</h1>

    <form method="post">

        <?php
        wp_nonce_field(
            'disi_save_configuration_action'
        );
        ?>

        <table class="form-table">

            <tr>

                <th>
                    Form Provider
                </th>

                <td>

                    <select
                        name="provider"
                        onchange="this.form.submit();"
                    >

                        <option value="">
                            Select Provider
                        </option>

                        <option
                            value="fluentforms"
                            <?php selected(
                                $provider,
                                'fluentforms'
                            ); ?>
                        >
                            Fluent Forms
                        </option>

                        <option
                            value="forminator"
                            <?php selected(
                                $provider,
                                'forminator'
                            ); ?>
                        >
                            Forminator
                        </option>

                    </select>

                    <p class="description">

                        Choose your form provider.

                    </p>

                </td>

            </tr>

            <tr>

                <th>
                    Participant Form
                </th>

                <td>

                    <select
                        name="participant_form"
                    >

                        <option value="">
                            Select Form
                        </option>

                        <?php
                        foreach ($forms as $form) :
                        ?>

                        <option

                            value="<?php
                            echo esc_attr(
                                $form->id
                            );
                            ?>"

                            <?php
                            selected(
                                $config['participant_form'] ?? '',
                                $form->id
                            );
                            ?>

                        >

                            <?php

                            echo esc_html(

                                $form->title
                                ??
                                $form->name

                            );

                            ?>

                        </option>

                        <?php endforeach; ?>

                    </select>

                </td>

            </tr>

            <tr>

                <th>
                    Vendor Form
                </th>

                <td>

                    <select
                        name="vendor_form"
                    >

                        <option value="">
                            Select Form
                        </option>

                        <?php
                        foreach ($forms as $form) :
                        ?>

                        <option

                            value="<?php
                            echo esc_attr(
                                $form->id
                            );
                            ?>"

                            <?php
                            selected(
                                $config['vendor_form'] ?? '',
                                $form->id
                            );
                            ?>

                        >

                            <?php

                            echo esc_html(

                                $form->title
                                ??
                                $form->name

                            );

                            ?>

                        </option>

                        <?php endforeach; ?>

                    </select>

                </td>

            </tr>

            <tr>

                <th>
                    Partner Form
                </th>

                <td>

                    <select
                        name="partner_form"
                    >

                        <option value="">
                            Select Form
                        </option>

                        <?php
                        foreach ($forms as $form) :
                        ?>

                        <option

                            value="<?php
                            echo esc_attr(
                                $form->id
                            );
                            ?>"

                            <?php
                            selected(
                                $config['partner_form'] ?? '',
                                $form->id
                            );
                            ?>

                        >

                            <?php

                            echo esc_html(

                                $form->title
                                ??
                                $form->name

                            );

                            ?>

                        </option>

                        <?php endforeach; ?>

                    </select>

                </td>

            </tr>

        </table>

        <p>

            <button
                type="submit"
                name="disi_save_configuration"
                class="button button-primary"
            >
                Save Configuration
            </button>

        </p>

    </form>

</div>