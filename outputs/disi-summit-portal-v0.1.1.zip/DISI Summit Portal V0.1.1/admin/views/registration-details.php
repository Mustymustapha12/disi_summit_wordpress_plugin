<?php

if (!defined('ABSPATH')) {
    exit;
}
/*
|--------------------------------------------------------------------------
| Handle Actions
|--------------------------------------------------------------------------
*/

if (

isset($_GET['action']) &&
isset($_GET['_wpnonce'])

) {

$action =
sanitize_text_field(
$_GET['action']
);

if (

$action === 'approve' &&
wp_verify_nonce(

$_GET['_wpnonce'],

'disi_approve_' .
intval($_GET['id'])

)

) {

DISI_Registration_Manager::approve(
intval($_GET['id'])
);

echo '
<div class="notice notice-success">
<p>
Registration approved successfully.
</p>
</div>
';

}

if (

$action === 'reject' &&
wp_verify_nonce(

$_GET['_wpnonce'],

'disi_reject_' .
intval($_GET['id'])

)

) {

DISI_Registration_Manager::reject(
intval($_GET['id'])
);

echo '
<div class="notice notice-success">
<p>
Registration rejected successfully.
</p>
</div>
';

}

}

if (

$action === 'reset' &&
wp_verify_nonce(

$_GET['_wpnonce'],

'disi_reset_' .
intval($_GET['id'])

)

) {

DISI_Registration_Manager::reset(
intval($_GET['id'])
);

echo '

<div class="notice notice-success">
<p>
Registration reset successfully.
</p>
</div>
';

}


$id = intval($_GET['id'] ?? 0);

$registration =
DISI_Registration_Manager::get($id);

if (!$registration) {

    echo '<div class="notice notice-error">
    <p>Registration not found.</p>
    </div>';

    return;
}

$data = json_decode(
    $registration->submitted_data,
    true
);

?>

<div class="wrap">

<div class="disi-details-container">

<h1>

Registration Details

</h1>

<div class="disi-summary-card">

    <div>

    <strong>
        Registration Number
    </strong>

    <br>

    <?php

        echo esc_html(

        DISI_Registration_Manager::get_registration_number(
            $registration
        )

    );

?>

</div>

<div>

<strong>Type:</strong>

<?php
echo esc_html(
ucfirst(
$registration->registration_type
)
);
?>

</div>

<div>

<strong>Status:</strong>

<span class="disi-status-badge disi-<?php echo esc_attr($registration->status); ?>">

<?php
echo esc_html(
ucfirst(
$registration->status
)
);
?>

</span>

</div>

<div>

<strong>Email:</strong>

<?php
echo esc_html(
$registration->email
);
?>

</div>

<div>

<strong>Date Submitted:</strong>

<?php
echo esc_html(
$registration->created_at
);
?>

</div>

<?php if (!empty($registration->approved_at)) : ?>

<div>

<strong>Approved At:</strong>

<?php
echo esc_html(
$registration->approved_at
);
?>

</div>

<?php endif; ?>

</div>

<h2>

Submitted Information

</h2>

<div class="disi-data-grid">

<?php

if (!empty($data)) :

foreach ($data as $key => $value) :

if (is_array($value)) {
$value = implode(', ', $value);
}

?>

<div class="disi-field">

<div class="disi-label">

<?php

echo esc_html(

ucwords(
str_replace(
'_',
' ',
$key
)
)

);

?>

</div>

<div class="disi-value">

<?php
echo esc_html(
$value
);
?>

</div>

</div>

<?php

endforeach;

endif;

?>

</div>

<div class="disi-actions">

<?php if ($registration->status === 'pending') : ?>

    <a
    href="<?php

    echo wp_nonce_url(

        admin_url(

            'admin.php?page=disi-registration-view&id=' .
            $registration->id .
            '&action=approve'

        ),

        'disi_approve_' .
        $registration->id

    );

    ?>"
    class="button disi-approve-btn"
    >

    Approve Registration

    </a>

    <a
    href="<?php

    echo wp_nonce_url(

        admin_url(

            'admin.php?page=disi-registration-view&id=' .
            $registration->id .
            '&action=reject'

        ),

        'disi_reject_' .
        $registration->id

    );

    ?>"
    class="button disi-reject-btn"
    >

    Reject Registration

    </a>

<?php endif; ?>

<?php if ($registration->status !== 'pending') : ?>


<?php endif; ?>



<a
href="<?php echo admin_url(
'admin.php?page=disi-registrations'
); ?>"
class="button"
>

Back

</a>

</div>

</div>

</div>
