<?php

if (!defined('ABSPATH')) {
    exit;
}

/*
|--------------------------------------------------------------------------
| Save Configuration
|--------------------------------------------------------------------------
*/

if (
    isset($_POST['disi_save_configuration']) &&
    check_admin_referer(
        'disi_save_configuration_action'
    )
) {

    $config = [

        'provider' => sanitize_text_field(
            $_POST['provider'] ?? ''
        ),

        'participant_form' => intval(
            $_POST['participant_form'] ?? 0
        ),

        'paystack_link' => esc_url_raw(
            $_POST['paystack_link'] ?? ''
        ),

        'payment_amount' => sanitize_text_field(
            $_POST['payment_amount'] ?? ''
        )

    ];

    DISI_Settings::save_configuration(
        $config
    );

    echo '
    <div class="notice notice-success">
        <p>Configuration saved successfully.</p>
    </div>
    ';
}

$config = DISI_Settings::get_configuration();


$provider =
$_POST['provider']
?? $config['provider']
?? '';

$forms = [];

if (!empty($provider)) {

    $forms =
    DISI_Form_Provider::get_forms(
        $provider
    );
}

?>

<div class="wrap">

    <h1>DISI Portal Integrations</h1>

    <form method="post">

        <?php
        wp_nonce_field(
            'disi_save_configuration_action'
        );
        ?>

        <table class="form-table">

            <tr>

                <th>
                    Form Provider
                </th>

                <td>

                    <select
                        name="provider"
                        onchange="this.form.submit();"
                    >

                        <option value="">
                            Select Provider
                        </option>

                        <option
                            value="fluentforms"
                            <?php selected(
                                $provider,
                                'fluentforms'
                            ); ?>
                        >
                            Fluent Forms
                        </option>

                        <option
                            value="forminator"
                            <?php selected(
                                $provider,
                                'forminator'
                            ); ?>
                        >
                            Forminator
                        </option>

                    </select>

                    <p class="description">

                        Choose your form provider.

                    </p>

                </td>

            </tr>

            <tr>

                <th>
                    Participants Form
                </th>

                <td>

                    <select
                        name="participant_form"
                    >

                        <option value="">
                            Select Form
                        </option>

                        <?php
                        foreach ($forms as $form) :
                        ?>

                        <option

                            value="<?php
                            echo esc_attr(
                                $form->id
                            );
                            ?>"

                            <?php
                            selected(
                                $config['participant_form'] ?? '',
                                $form->id
                            );
                            ?>

                        >

                            <?php

                            echo esc_html(

                                $form->title
                                ??
                                $form->name

                            );

                            ?>

                        </option>

                        <?php endforeach; ?>

                    </select>

                </td>

            </tr>

            <tr>

                <th>
                    Paystack Payment Link
                </th>

                <td>

                    <input
                        type="url"
                        name="paystack_link"
                        class="regular-text"
                        value="<?php echo esc_attr($config['paystack_link'] ?? ''); ?>"
                        placeholder="https://paystack.com/pay/..."
                    >

                    <p class="description">

                        This link is sent to approved participants.

                    </p>

                </td>

            </tr>

            <tr>

                <th>
                    Payment Amount
                </th>

                <td>

                    <input
                        type="text"
                        name="payment_amount"
                        class="regular-text"
                        value="<?php echo esc_attr($config['payment_amount'] ?? ''); ?>"
                        placeholder="NGN 50,000"
                    >

                    <p class="description">

                        This amount is included in approval emails.

                    </p>

                </td>

            </tr>

        </table>

        <p>

            <button
                type="submit"
                name="disi_save_configuration"
                class="button button-primary"
            >
                Save Configuration
            </button>

        </p>

    </form>

</div>
