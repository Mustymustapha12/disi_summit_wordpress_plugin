<?php

if (!defined('ABSPATH')) {
    exit;
}

class DISI_Activator {

    public static function activate() {

        if (class_exists('DISI_Database')) {

            DISI_Database::maybe_upgrade();
        }

        if (class_exists('DISI_Roles')) {

            DISI_Roles::create_roles();
        }

        flush_rewrite_rules();
    }
}