<?php

if (!defined('ABSPATH')) {
    exit;
}

class DISI_Email {

    public static function send_approval_email(
        $registration
    ) {

        error_log(
            'DISI EMAIL METHOD STARTED'
        );

        if (
            empty($registration->email)
        ) {
            return false;
        }

        $registration_number =
        DISI_Registration_Manager::get_registration_number(
            $registration
        );

        $config =
        DISI_Settings::get_configuration();

        $subject =
        'DISI Summit 2026 Registration Approved - Proceed With Payment';

        $logo =
        'https://disisummit.org/wp-content/uploads/2026/06/cropped-Black_White_Minimal_Professional_Corporate_Business_Logo-removebg-preview.png';

        $payment_link =
        esc_url(
            $config['paystack_link'] ?? ''
        );

        $payment_amount =
        sanitize_text_field(
            $config['payment_amount'] ?? ''
        );

        $name =
        trim(
            $registration->first_name .
            ' ' .
            $registration->last_name
        );

        if (empty($name)) {
            $name = 'Participant';
        }

        $message = '

        <html>

        <body style="
            margin:0;
            padding:0;
            background:#f3f4f6;
            font-family:Arial,sans-serif;
        ">

        <div style="
            max-width:700px;
            margin:30px auto;
            background:#ffffff;
            border-radius:12px;
            overflow:hidden;
        ">

            <div style="
                background:#22c55e;
                padding:30px;
                text-align:center;
            ">

                <img
                src="' . esc_url($logo) . '"
                style="
                    max-width:180px;
                "
                >

            </div>

            <div style="
                padding:40px;
            ">

                <h2>
                    DISI Summit 2026 Registration Approved
                </h2>

                <p>

                    Dear ' . esc_html($name) . ',

                </p>

                <p>

                    Congratulations. Your DISI Summit 2026 registration
                    has been approved. Please proceed with payment to
                    complete your registration.

                </p>

                <table
                cellpadding="8"
                style="
                    width:100%;
                    margin:20px 0;
                    border-collapse:collapse;
                "
                >

                    <tr>
                        <td>
                            Registration Number
                        </td>

                        <td>
                            <strong>' .
                            esc_html(
                                $registration_number
                            ) .
                            '</strong>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            Amount to Pay
                        </td>

                        <td>
                            <strong>' .
                            esc_html(
                                !empty($payment_amount)
                                ? $payment_amount
                                : 'To be confirmed'
                            ) .
                            '</strong>
                        </td>
                    </tr>

                </table>

                <p>

                    Click the button below to make payment.

                </p>

                ' . (
                    !empty($payment_link)
                    ? '
                <p
                style="
                    text-align:center;
                    margin:40px 0;
                "
                >

                    <a
                    href="' . $payment_link . '"
                    style="
                        background:#f59e0b;
                        color:#ffffff;
                        text-decoration:none;
                        padding:14px 28px;
                        border-radius:8px;
                        display:inline-block;
                        font-weight:bold;
                    "
                    >

                    Pay Now

                    </a>

                </p>

                <p>

                    If the button does not work, copy and paste this link
                    into your browser:

                    <a href="' . $payment_link . '">
                        ' . esc_html($payment_link) . '
                    </a>

                </p>
                    '
                    : '
                <p>
                    Payment details will be shared with you shortly.
                </p>
                    '
                ) . '

            </div>

        </div>

        </body>

        </html>

        ';

        $headers = [

            'Content-Type: text/html; charset=UTF-8',

            'From: DISI Summit Portal <noreply@disisummit.org>'

        ];

        return wp_mail(
            $registration->email,
            $subject,
            $message,
            $headers
        );
    }

    public static function send_rejection_email(
        $registration
    ) {

        if (
            empty($registration->email)
        ) {
            return false;
        }

        $registration_number =
        DISI_Registration_Manager::get_registration_number(
            $registration
        );

        $subject =
        'DISI Summit 2026 Registration Update';

        $name =
        trim(
            $registration->first_name .
            ' ' .
            $registration->last_name
        );

        if (empty($name)) {
            $name = 'Participant';
        }

        $message = '

        <html>

        <body style="
            margin:0;
            padding:0;
            background:#f3f4f6;
            font-family:Arial,sans-serif;
        ">

        <div style="
            max-width:700px;
            margin:30px auto;
            background:#ffffff;
            border-radius:12px;
            overflow:hidden;
        ">

            <div style="
                background:#111827;
                color:#ffffff;
                padding:30px;
                text-align:center;
            ">

                <h2 style="margin:0;">
                    DISI Summit 2026
                </h2>

            </div>

            <div style="
                padding:40px;
            ">

                <p>
                    Dear ' . esc_html($name) . ',
                </p>

                <p>
                    Thank you for your interest in DISI Summit 2026.
                    After reviewing your registration, we are unable to
                    approve it at this time.
                </p>

                <p>
                    Registration Number:
                    <strong>' . esc_html($registration_number) . '</strong>
                </p>

                <p>
                    If you believe this was a mistake, please contact the
                    DISI Summit team for assistance.
                </p>

            </div>

        </div>

        </body>

        </html>

        ';

        $headers = [

            'Content-Type: text/html; charset=UTF-8',

            'From: DISI Summit 2026 <noreply@disisummit.org>'

        ];

        return wp_mail(
            $registration->email,
            $subject,
            $message,
            $headers
        );
    }
}
