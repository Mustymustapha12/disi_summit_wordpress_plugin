<?php

if (!defined('ABSPATH')) {
    exit;
}

class DISI_Form_Provider {

    public static function get_forms($provider = '') {

        global $wpdb;

        if ($provider === 'fluentforms') {

            $table =
                $wpdb->prefix .
                'fluentform_forms';

            $exists =
                $wpdb->get_var(
                    $wpdb->prepare(
                        "SHOW TABLES LIKE %s",
                        $table
                    )
                );

            if ($exists !== $table) {
                return [];
            }

            return $wpdb->get_results(
                "SELECT id,title
                 FROM {$table}
                 ORDER BY title ASC"
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Forminator
        |--------------------------------------------------------------------------
        */

        if ($provider === 'forminator') {

            if (
                class_exists(
                    'Forminator_API'
                )
            ) {

                try {

                    $forms =
                    Forminator_API::get_forms();

                    if (
                        is_array($forms)
                    ) {
                        return $forms;
                    }

                } catch (
                    Exception $e
                ) {

                    return [];
                }
            }

            return [];
        }

        return [];
    }
}