<?php

if (!defined('ABSPATH')) {
    exit;
}

class DISI_Registration_Manager {

    /**
     * Create registration
     */
    public static function create($data = []) {

        global $wpdb;

        $table = DISI_Database::get_table();

        if (empty($data['email'])) {
            return false;
        }

        $email = sanitize_email($data['email']);

        /*
        |--------------------------------------------------------------------------
        | Duplicate Email Check
        |--------------------------------------------------------------------------
        */

        if (
            self::email_exists($email)
        ) {

            return new WP_Error(
                'duplicate_email',
                'This email is already registered.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Duplicate Phone Check
        |--------------------------------------------------------------------------
        */

        if (
            !empty($data['phone']) &&
            self::phone_exists(
                $data['phone']
            )
        ) {

            return new WP_Error(
                'duplicate_phone',
                'This phone number is already registered.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Insert registration
        |--------------------------------------------------------------------------
        */

        $wpdb->insert(
            $table,
            [

                'registration_type' =>
                    sanitize_text_field(
                        $data['registration_type'] ?? ''
                    ),

                'source_plugin' =>
                    sanitize_text_field(
                        $data['source_plugin'] ?? ''
                    ),

                'form_id' =>
                    intval(
                        $data['form_id'] ?? 0
                    ),

                'email' => $email,

                'phone' =>
                    sanitize_text_field(
                        $data['phone'] ?? ''
                    ),

                'first_name' =>
                    sanitize_text_field(
                        $data['first_name'] ?? ''
                    ),

                'last_name' =>
                    sanitize_text_field(
                        $data['last_name'] ?? ''
                    ),

                'business_name' =>
                    sanitize_text_field(
                        $data['business_name'] ?? ''
                    ),

                'status' => 'pending',

                'submitted_data' =>
                    wp_json_encode(
                        $data['submitted_data'] ?? []
                    ),

                'created_at' =>
                    current_time('mysql'),

                'updated_at' =>
                    current_time('mysql')

            ]
        );

        return $wpdb->insert_id;
    }

    /**
     * Get all registrations
     */
    public static function get_all() {

        global $wpdb;

        $table = DISI_Database::get_table();

        return $wpdb->get_results(

            "SELECT *
             FROM {$table}
             ORDER BY id DESC"

        );
    }

    /**
     * Get registration by ID
     */
    public static function get($id) {

        global $wpdb;

        $table = DISI_Database::get_table();

        return $wpdb->get_row(

            $wpdb->prepare(
                "SELECT *
                 FROM {$table}
                 WHERE id = %d",
                $id
            )

        );
    }

    /**
     * Delete registration
    
    public static function delete($id) {

        global $wpdb;

        $table = DISI_Database::get_table();

        return $wpdb->delete(
            $table,
            [
                'id' => intval($id)
            ]
        );
    }
     */

    /**
     * Count registrations
     */
    public static function count($status = null) {

        global $wpdb;

        $table = DISI_Database::get_table();

        if ($status) {

            return $wpdb->get_var(

                $wpdb->prepare(
                    "SELECT COUNT(*)
                     FROM {$table}
                     WHERE status = %s",
                    $status
                )

            );
        }

        return $wpdb->get_var(
            "SELECT COUNT(*)
             FROM {$table}"
        );
    }
    /**
     * Get registrations with filters and pagination
     */
    public static function get_paginated(
        $page = 1,
        $per_page = 20,
        $type = '',
        $status = '',
        $search = ''
    ) {

        global $wpdb;

        $table = DISI_Database::get_table();

        $where = "WHERE 1=1";

        if (!empty($type)) {

            $where .= $wpdb->prepare(
                " AND registration_type = %s",
                $type
            );
        }

        if (!empty($status)) {

            $where .= $wpdb->prepare(
                " AND status = %s",
                $status
            );
        }

        if (!empty($search)) {

            $search_term = '%' .
            $wpdb->esc_like($search) .
            '%';

            $where .= $wpdb->prepare(
                " AND (
                    email LIKE %s
                    OR first_name LIKE %s
                    OR last_name LIKE %s
                    OR business_name LIKE %s
                )",
                $search_term,
                $search_term,
                $search_term,
                $search_term
            );
        }

        $offset =
        ($page - 1) * $per_page;

        return $wpdb->get_results(

            $wpdb->prepare(
                "SELECT *
                 FROM {$table}
                 {$where}
                 ORDER BY id DESC
                 LIMIT %d OFFSET %d",
                $per_page,
                $offset
            )

        );
    }
    public static function total_count(
        $type = '',
        $status = '',
        $search = ''
    ) {

        global $wpdb;

        $table = DISI_Database::get_table();

        $where = "WHERE 1=1";

        if (!empty($type)) {

            $where .= $wpdb->prepare(
                " AND registration_type=%s",
                $type
            );
        }

        if (!empty($status)) {

            $where .= $wpdb->prepare(
                " AND status=%s",
                $status
            );
        }

        if (!empty($search)) {

            $term =
            '%' .
            $wpdb->esc_like($search) .
            '%';

            $where .= $wpdb->prepare(
                " AND (
                    email LIKE %s
                    OR first_name LIKE %s
                    OR last_name LIKE %s
                    OR business_name LIKE %s
                )",
                $term,
                $term,
                $term,
                $term
            );
        }

        return $wpdb->get_var(
            "SELECT COUNT(*)
             FROM {$table}
             {$where}"
        );
    }
    /**
     * Approve registration
     */
    public static function approve(
        $registration_id
        ) {

        global $wpdb;

        $registration =
        self::get(
            $registration_id
        );

        if (
            !$registration ||
            $registration->status !== 'pending'
        ) {
            return false;
        }

        $table =
        DISI_Database::get_table();

        $updated = $wpdb->update(

            $table,

            [

                'status' => 'approved',

                'approved_by' =>
                    get_current_user_id(),

                'approved_at' =>
                    current_time('mysql'),

                'updated_at' =>
                    current_time('mysql')

            ],

            [

                'id' =>
                    intval(
                        $registration_id
                    )

            ]

        );

        if ($updated !== false) {

            $registration =
            self::get(
                $registration_id
            );

            error_log(
                'DISI APPROVAL EMAIL FUNCTION CALLED'
            );

            if (
                class_exists(
                    'DISI_Email'
                )
            ) {

                DISI_Email::send_approval_email(
                    $registration
                );
            }
        }

        return $updated;
        

        }


    /**
     * Reject registration
     */
    public static function reject(
        $registration_id
    ) {

        $registration = self::get(
            $registration_id
        );

        if (
            !$registration ||
            $registration->status !== 'pending'
        ) {
            return false;
        }

        global $wpdb;

        $table = DISI_Database::get_table();

        $updated = $wpdb->update(

            $table,

            [

                'status' => 'rejected',

                'updated_at' => current_time('mysql')

            ],

            [

                'id' => intval(
                    $registration_id
                )

            ]

        );

        if ($updated !== false) {

            $registration = self::get(
                $registration_id
            );

            if (
                class_exists(
                    'DISI_Email'
                )
            ) {

                DISI_Email::send_rejection_email(
                    $registration
                );
            }
        }

        return $updated;
    }
    /**
     * Check if email exists
     */
    public static function email_exists($email)
    {
        global $wpdb;

        $table = DISI_Database::get_table();

        return $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM {$table}
                 WHERE email = %s
                 LIMIT 1",
                sanitize_email($email)
            )
        );
    }

    /**
     * Check if phone exists
     */
    public static function phone_exists($phone)
    {
        global $wpdb;

        $table = DISI_Database::get_table();

        return $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM {$table}
                 WHERE phone = %s
                 LIMIT 1",
                sanitize_text_field($phone)
            )
        );
    }
    /**
     * Generate Registration Number
     */
    public static function get_registration_number(
        $registration
    ) {

        return sprintf(

            'DISI-%s-%06d',

            date(
                'Y',
                strtotime(
                    $registration->created_at
                )
            ),

            intval(
                $registration->id
            )

        );
    }

    /**
     * Count by registration type
     */
    public static function count_by_type(
        $type
    ) {

        global $wpdb;

        $table =
        DISI_Database::get_table();

        return $wpdb->get_var(

            $wpdb->prepare(

                "SELECT COUNT(*)
                 FROM {$table}
                 WHERE registration_type = %s",

                $type

            )

        );
    }




}
